/**
 * Created by Administrator on 2016/8/23.
 * @author 陈星宇 271173104@qq.com
 * 缺点 ， 跟html文件绑定的很死。
 */
"use strict";

(function(window, factory) {
    //amd写法
    if (typeof define === 'function' && define.amd) {
        define(['$'], factory);
        //umd 写法 ， 暴露接口
    } else if (typeof exports === 'object') {
        module.exports = factory();
    } else {
        //否则暴露给window
        window.Calendar = factory();
    }
})(this, function (){

    //获取对象
    function getByClass(oPare, cla) {
        var oChild = oPare.getElementsByTagName("*");
        var arr = [];
        for (var i = 0; i < oChild.length; i++) {
            var itemCla = oChild[i].className.split(" ");
            for (var obj in itemCla) {
                if (itemCla[obj] == cla) {
                    arr.push(oChild[i]);
                    break;
                }
            }
        }
        return arr;
    };

    //构造函数
    function Calendar(opt) {
        var self = this;

        //如果没有使用new关键字 ， 这里实例化Calendar构造函数
        if (!(self instanceof Calendar)) {
            return new Calendar(opt);
        }

        self.obj = document.getElementById(opt.id);

        self.dateText = getByClass(self.obj, 'showDate')[0];
        self.dateBox = getByClass(self.obj, 'sel_date')[0];
        self.yearBox = getByClass(self.obj, 'year')[0];
        self.monthBox = getByClass(self.obj, 'month')[0];

        self.dataTable = getByClass(self.dateBox, "data_table")[0];
        self.tbody = self.dataTable.tBodies[0];
        self.td = self.tbody.getElementsByTagName("td");
        self.prevM = getByClass(self.dateBox, "prev_m")[0];
        self.nextM = getByClass(self.dateBox, "next_m")[0];
        self.prevY = getByClass(self.dateBox, "prev_y")[0];
        self.nextY = getByClass(self.dateBox, "next_y")[0];
        self.init();
    };

    //原型方法
    Calendar.prototype = {
        //初始化
        init: function () {
            var self = this;
            //input获得焦点显示日期
            self.dateText.onfocus = function (event) {
                event = event || window.event;
                event.stopPropagation();
                self.changeDefault(this);
                //显示日历
                self.show();
                //显示时间日期
                self.showNow();
            };

            //点击空白 隐藏日历
            document.onclick = function (event) {
                event = event || window.event;
                event.stopPropagation();
                var target = event.target || event.srcElement;
                self.hide(event, target, this);
            };

            //点击选择日期
            for (var i = 0; i < self.td.length; i++) {
                var itemTd = self.td[i];
                //点击每一个td
                itemTd.addEventListener('click',function (){
                    var newDd = this.innerHTML;
                    var newYear = self.yearBox.value;
                    var newMn = self.monthBox.value;
                    if (newDd.match(/^\s{0}$/g)) {  //如果td没有值;
                        return false;
                    }
                    self.dateText.value = newYear + "年" + newMn + "月" + newDd + "日";
                    self.dateBox.className += " dn";
                },false);
                //鼠标移过每一个td
                itemTd.addEventListener('mouseenter',function (){
                    if (this.className.indexOf("hove") == -1) {
                        this.className += " hover";
                    }
                },false);
                //鼠标移除每一个td
                itemTd.addEventListener('mouseleave',function (){
                    this.className = this.className.replace("hover","")
                },false);
            }

            //点击切换月份
            self.prevM.onclick = self.nextM.onclick = function () {
                self.changeMn(this);
                return this;
            };

            //点击切换年份
            self.prevY.onclick = self.nextY.onclick = function (){
                self.changeYear(this);
            };

        },
        //文本框 清空初始值
        changeDefault: function (obj) {
            var deVal = obj.defaultValue;
            if (obj.value == deVal) {
                obj.value = "";
            }
        },
        //文本框 还原初始值
        changeDefault2: function (obj) {
            var deVal = obj.defaultValue;
            if (obj.value.match(/^\s{0}$/)) {
                obj.value = deVal;
            }
        },
        //显示日历
        show: function () {
            var self = this;
            if (self.dateBox.className.indexOf("dn") != -1) {
                var cls = self.dateBox.className;
                self.dateBox.className = cls.replace("dn", "");
            }
        },
        //隐藏日历
        hide: function (event, target, obj) {
            var self = this;
            var oPare = target.parentNode;
            var isChild = true; //默认是子元素
            if (oPare == obj || target == obj) {
                isChild = false;
            } else {
                loop: while (oPare != self.obj) {
                    oPare = oPare.parentNode;
                    if (oPare == obj) {
                        isChild = false;
                        break loop;
                    }
                }
            }
            if (!isChild && self.dateBox.className.indexOf("dn") == -1) {
                self.dateBox.className += " dn";
                self.changeDefault2(self.dateText);
            }
        },
        //切换月份
        changeMn : function (obj){
            var self = this;
            var newMn = parseInt(self.monthBox.value, 10);
            var newYear = parseInt(self.yearBox.value, 10);
            if (obj == self.nextM) {
                newMn++;
            } else {
                newMn--;
            }
            //判断最小最大月份
            if(newMn < 1){
                newMn = 12;
                newYear = newYear - 1;
            }else if(newMn > 12){
                newMn = 1;
                newYear = newYear + 1;
            }

            //填充年、月
            self.showNow(newYear, newMn);
        },
        //切换年份
        changeYear : function (obj){
            var self = this;
            var newMn = parseInt(self.monthBox.value, 10);
            var newYear = parseInt(self.yearBox.value, 10);
            if (obj == self.nextY) {
                newYear++;
            } else {
                newYear--;
            }
            //判断最小最大年份
            if (newYear < 1900) {
                newYear = 1900;
            } else if (newYear > 2099) {
                newYear = 2099;
            }

            //填充年、月
            self.showNow(newYear, newMn);
        },
        //填充年、月
        showNow: function (yr, mn) {
            var self = this;
            var now = new Date();
            var year = yr || now.getFullYear();
            var month = mn - 1 || now.getMonth();
            var dd = now.getDate();

            //填充 年 和 月
            self.yearBox.value = year;
            self.monthBox.value = mn || now.getMonth() + 1;

            //填充日期
            self.showDay(year, month, dd);
        },
        //填充所有日期
        showDay: function (Yr, Mn, Dd) {
            var self = this;
            var arr31 = [1, 3, 5, 7, 8, 10, 12];
            var newDd = new Date(Yr, Mn, Dd);  //根据传入的数值生成新的日期
            var year = newDd.getFullYear(),  //指定年份
                month = newDd.getMonth(), //指定月份
                dd = newDd.getDate();  //指定日期

            var n1str = new Date(year, month, 1); //指定月第一天Date资讯
            var firstDay = n1str.getDay(); //指定月第一天星期几

            //当前的年月日
            var curDate = new Date(),
                curYear = curDate.getFullYear(),
                curMonth = curDate.getMonth() + 1,
                curDd =  curDate.getDate();

            var str31 = arr31.join(",");
            //传入月份 ， 生成正则表达式字符串 ， 如8月， /8,|,8,|,8/g
            var regExp = eval("/" + (month + 1) + ",|," + (month + 1) + ",|," + (month + 1) + "/g");
            var dayLen = 31;
            //判断这个月是否有31号
            if(str31.search(regExp) == -1) {
                dayLen = 30;
            }
            //清空日期 , 样式
            for (var i = 0; i < self.td.length; i++) {
                self.td[i].innerHTML = "";
                self.td[i].className = self.td[i].className.replace("active", "");
            }

            var yearBoxValue = parseInt(self.yearBox.value),
                monthBoxValue = parseInt(self.monthBox.value);

            //如果有31天
            for (var i = 0; i < dayLen; i++) {
                //渲染每一天
                self.td[i + firstDay].innerHTML = i + 1;
                //给当天添加高亮样式 , 判断今年今月今日
                if ( i + 1 == curDd &&
                    curYear === yearBoxValue &&
                    curMonth === monthBoxValue &&
                    self.td[i + firstDay].className.indexOf("active")==-1
                ){
                    self.td[i + firstDay].className += " active";
                }
            }
        }
    };

    //返回函数对象
    return Calendar;

});